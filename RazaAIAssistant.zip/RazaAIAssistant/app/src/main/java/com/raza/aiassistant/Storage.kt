package com.raza.aiassistant

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.serialization.encodeToString
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json
import java.io.ByteArrayInputStream
import java.io.File

class Storage(private val ctx: Context) {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val prefs = ctx.getSharedPreferences("raza_prefs", Context.MODE_PRIVATE)
    private val chatDir = File(ctx.filesDir, "chats").apply { mkdirs() }
    val attachDir = File(ctx.filesDir, "attachments").apply { mkdirs() }

    // Provider configs (including API keys) are stored encrypted with an Android Keystore key.
    fun loadProviders(): List<Provider> {
        val enc = prefs.getString("providers", null) ?: return emptyList()
        val plain = SecureStore.decrypt(enc) ?: return emptyList()
        return runCatching { json.decodeFromString<List<Provider>>(plain) }.getOrDefault(emptyList())
    }

    fun saveProviders(list: List<Provider>) {
        prefs.edit().putString("providers", SecureStore.encrypt(json.encodeToString(list))).apply()
    }

    fun loadSettings(): Settings =
        prefs.getString("settings", null)?.let { runCatching { json.decodeFromString<Settings>(it) }.getOrNull() } ?: Settings()

    fun saveSettings(s: Settings) {
        prefs.edit().putString("settings", json.encodeToString(s)).apply()
    }

    fun loadChats(): List<Chat> =
        chatDir.listFiles()?.mapNotNull { f -> runCatching { json.decodeFromString<Chat>(f.readText()) }.getOrNull() }
            ?.sortedByDescending { it.updated } ?: emptyList()

    fun saveChat(c: Chat) {
        File(chatDir, "${c.id}.json").writeText(json.encodeToString(c))
    }

    fun deleteChat(c: Chat) {
        File(chatDir, "${c.id}.json").delete()
        c.messages.flatMap { it.attachments }.forEach { File(it.path).delete() }
    }

    fun importAttachment(uri: Uri): Attachment = Attachments.import(ctx, uri, attachDir)
}

object Attachments {
    private val textExt = setOf(
        "txt", "md", "csv", "tsv", "json", "xml", "html", "htm", "css", "js", "ts", "kt", "java", "py", "c", "cpp",
        "h", "cs", "go", "rs", "rb", "php", "sh", "sql", "yaml", "yml", "toml", "ini", "log", "tex", "gradle"
    )

    fun import(ctx: Context, uri: Uri, dir: File): Attachment {
        val cr = ctx.contentResolver
        var name = "file"
        cr.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && i >= 0) name = c.getString(i) ?: name
        }
        val ext = name.substringAfterLast('.', "").lowercase()
        val mime = cr.getType(uri).orEmpty()
        val isImage = mime.startsWith("image/")
        val isPdf = mime == "application/pdf" || ext == "pdf"
        val isText = mime.startsWith("text/") || ext in textExt || mime == "application/json" || mime == "application/xml"
        val id = newId()

        fun read(limit: Int): ByteArray {
            val bytes = cr.openInputStream(uri)?.use { it.readBytes() } ?: error("Cannot read $name")
            if (bytes.size > limit) error("$name is too large (max ${limit / 1_000_000} MB).")
            return bytes
        }

        return when {
            isImage -> {
                val bytes = read(25_000_000)
                val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
                var sample = 1
                while (maxOf(opts.outWidth, opts.outHeight) / sample > 2000) sample *= 2
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
                    ?: error("$name is not a readable image.")
                val orient = runCatching {
                    ExifInterface(ByteArrayInputStream(bytes)).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)
                val deg = when (orient) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
                val out = if (deg != 0f) Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true) else bmp
                val f = File(dir, "$id.jpg")
                f.outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 85, it) }
                Attachment(name, "image/jpeg", f.absolutePath)
            }
            isPdf -> {
                val f = File(dir, "$id.pdf").also { it.writeBytes(read(15_000_000)) }
                Attachment(name, "application/pdf", f.absolutePath)
            }
            isText -> {
                val f = File(dir, "$id.txt").also { it.writeBytes(read(2_000_000)) }
                Attachment(name, "text/plain", f.absolutePath)
            }
            else -> error("“$name” is not supported. Supported: images, PDF, and plain-text/code files (txt, md, csv, json, source code…). Word/Excel files cannot be read yet.")
        }
    }
}
