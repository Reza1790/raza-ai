package com.raza.aiassistant

import android.graphics.BitmapFactory
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/** 3D-style animated orb: lit sphere + two counter-rotating orbit rings + soft glow. */
@Composable
fun AiOrb(dimension: Dp = 160.dp) {
    val t = rememberInfiniteTransition(label = "orb")
    val rot by t.animateFloat(0f, 360f, infiniteRepeatable(tween(14000, easing = LinearEasing)), label = "rot")
    val pulse by t.animateFloat(0.96f, 1.04f, infiniteRepeatable(tween(2400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
    Canvas(Modifier.size(dimension)) {
        val c = center
        val half = this.size.minDimension / 2
        val r = half * 0.55f * pulse
        drawCircle(Brush.radialGradient(listOf(Raza.Cyan.copy(alpha = 0.35f), Color.Transparent), c, half), half, c)
        drawCircle(
            Brush.radialGradient(
                listOf(Color(0xFFC9F8FF), Raza.Cyan, Raza.Violet, Color(0xFF1B1140)),
                center = Offset(c.x - r * 0.35f, c.y - r * 0.4f), radius = r * 1.6f
            ), r, c
        )
        val ringStroke = Stroke(width = 2.5.dp.toPx())
        rotate(rot, c) {
            drawOval(
                Brush.sweepGradient(listOf(Color.Transparent, Raza.Pink, Raza.Cyan, Color.Transparent), c),
                Offset(c.x - r * 1.5f, c.y - r * 0.5f), Size(r * 3f, r), style = ringStroke
            )
        }
        rotate(-rot * 0.7f + 60f, c) {
            drawOval(
                Brush.sweepGradient(listOf(Color.Transparent, Raza.Violet, Raza.Cyan, Color.Transparent), c),
                Offset(c.x - r * 1.35f, c.y - r * 0.4f), Size(r * 2.7f, r * 0.8f), style = ringStroke
            )
        }
    }
}

@Composable
fun TypingDots() {
    val t = rememberInfiniteTransition(label = "dots")
    Row(Modifier.padding(6.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        repeat(3) { i ->
            val a by t.animateFloat(0.25f, 1f, infiniteRepeatable(tween(600, delayMillis = i * 150), RepeatMode.Reverse), label = "d$i")
            Box(Modifier.size(8.dp).clip(CircleShape).background(Raza.Cyan.copy(alpha = a)))
        }
    }
}

// ---------------- Markdown ----------------
sealed interface Block {
    data class Code(val lang: String, val code: String) : Block
    data class Line(val text: String, val level: Int = 0, val bullet: String? = null) : Block
}

fun parseBlocks(src: String): List<Block> {
    val out = mutableListOf<Block>()
    val lines = src.split("\n")
    val head = Regex("^(#{1,6})\\s+(.*)")
    val bul = Regex("^\\s*[-*•]\\s+(.*)")
    val num = Regex("^\\s*(\\d+)[.)]\\s+(.*)")
    var i = 0
    while (i < lines.size) {
        val l = lines[i]
        if (l.trimStart().startsWith("```")) {
            val lang = l.trim().removePrefix("```").trim()
            val sb = StringBuilder()
            i++
            while (i < lines.size && !lines[i].trimStart().startsWith("```")) { sb.append(lines[i]).append('\n'); i++ }
            out += Block.Code(lang, sb.toString().trimEnd('\n'))
            i++
            continue
        }
        val h = head.find(l); val b = bul.find(l); val n = num.find(l)
        when {
            h != null -> out += Block.Line(h.groupValues[2], level = h.groupValues[1].length)
            b != null -> out += Block.Line(b.groupValues[1], bullet = "•")
            n != null -> out += Block.Line(n.groupValues[2], bullet = n.groupValues[1] + ".")
            l.isNotBlank() -> out += Block.Line(l)
        }
        i++
    }
    return out
}

fun inlineMd(s: String, codeBg: Color, codeFg: Color): AnnotatedString = buildAnnotatedString {
    var i = 0
    while (i < s.length) {
        if (s.startsWith("**", i)) {
            val e = s.indexOf("**", i + 2)
            if (e >= 0) { withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(s.substring(i + 2, e)) }; i = e + 2; continue }
        }
        if (s[i] == '`') {
            val e = s.indexOf('`', i + 1)
            if (e >= 0) {
                withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = codeBg, color = codeFg)) { append(s.substring(i + 1, e)) }
                i = e + 1; continue
            }
        }
        append(s[i]); i++
    }
}

@Composable
fun Markdown(text: String) {
    val cs = MaterialTheme.colorScheme
    val blocks = remember(text) { parseBlocks(text) }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        blocks.forEach { b ->
            when (b) {
                is Block.Code -> CodeBlock(b.lang, b.code)
                is Block.Line -> {
                    val size = when (b.level) { 1 -> 22.sp; 2 -> 20.sp; 3 -> 18.sp; else -> 16.sp }
                    val style = TextStyle(
                        textDirection = TextDirection.Content, fontSize = size, lineHeight = size * 1.45f, color = cs.onSurface,
                        fontWeight = if (b.level > 0) FontWeight.Bold else FontWeight.Normal
                    )
                    val ann = inlineMd(b.text, cs.surfaceVariant, cs.primary)
                    if (b.bullet != null) {
                        Row {
                            Text(b.bullet, style = style, color = cs.primary, modifier = Modifier.padding(end = 8.dp))
                            Text(ann, style = style, modifier = Modifier.weight(1f))
                        }
                    } else Text(ann, style = style)
                }
            }
        }
    }
}

@Composable
fun CodeBlock(lang: String, code: String) {
    val clip = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(copied) { if (copied) { delay(1500); copied = false } }
    val shape = RoundedCornerShape(12.dp)
    Column(Modifier.fillMaxWidth().clip(shape).background(Color(0xFF0A0F1F)).border(1.dp, Color(0xFF263056), shape)) {
        Row(Modifier.fillMaxWidth().background(Color(0xFF131B36)).padding(start = 12.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(lang.ifBlank { "code" }, color = Raza.Cyan, fontSize = 12.sp, modifier = Modifier.weight(1f))
            TextButton(onClick = { clip.setText(AnnotatedString(code)); copied = true }) {
                Icon(if (copied) Icons.Filled.Check else Icons.Filled.ContentCopy, null, Modifier.size(14.dp))
                Spacer(Modifier.width(4.dp))
                Text(if (copied) "Copied" else "Copy", fontSize = 12.sp)
            }
        }
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Text(
                code, fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = Color(0xFFD6E2FF), softWrap = false,
                modifier = Modifier.horizontalScroll(rememberScrollState()).padding(12.dp)
            )
        }
    }
}

// ---------------- Attachments & bubbles ----------------
@Composable
fun AttachmentPreview(a: Attachment, onRemove: (() -> Unit)?) {
    val cs = MaterialTheme.colorScheme
    Box {
        if (a.mime.startsWith("image/")) {
            val bmp = remember(a.path) {
                runCatching { BitmapFactory.decodeFile(a.path, BitmapFactory.Options().apply { inSampleSize = 8 })?.asImageBitmap() }.getOrNull()
            }
            Box(Modifier.size(64.dp).clip(RoundedCornerShape(12.dp)).background(cs.surfaceVariant)) {
                if (bmp != null) Image(bmp, a.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            }
        } else {
            Row(
                Modifier.height(40.dp).clip(RoundedCornerShape(12.dp)).background(cs.surfaceVariant).padding(horizontal = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(if (a.mime == "application/pdf") Icons.Filled.PictureAsPdf else Icons.Filled.Description, null, Modifier.size(18.dp), tint = cs.primary)
                Spacer(Modifier.width(6.dp))
                Text(a.name.take(22), fontSize = 13.sp, maxLines = 1, color = cs.onSurface)
            }
        }
        if (onRemove != null) {
            Box(
                Modifier.align(Alignment.TopEnd).size(20.dp).clip(CircleShape).background(cs.error).clickable(onClick = onRemove),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.Close, "Remove", Modifier.size(12.dp), tint = Color.White) }
        }
    }
}

@Composable
fun MessageBubble(m: Message, isLast: Boolean, onCopy: () -> Unit, onSpeak: () -> Unit, onRegenerate: () -> Unit) {
    val isUser = m.role == "user"
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (isUser) Alignment.End else Alignment.Start) {
        if (m.attachments.isNotEmpty()) {
            Row(Modifier.padding(bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                m.attachments.forEach { AttachmentPreview(it, null) }
            }
        }
        if (isUser) {
            if (m.text.isNotBlank()) {
                Box(
                    Modifier.widthIn(max = 320.dp)
                        .clip(RoundedCornerShape(20.dp, 20.dp, 4.dp, 20.dp))
                        .background(Brush.linearGradient(listOf(Color(0xFF6D3BE0), Color(0xFF2563EB))))
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    Text(m.text, color = Color.White, style = TextStyle(textDirection = TextDirection.Content, fontSize = 16.sp, lineHeight = 23.sp))
                }
            }
        } else {
            Surface(
                shape = RoundedCornerShape(20.dp, 20.dp, 20.dp, 4.dp),
                color = if (m.isError) cs.errorContainer else cs.surface.copy(alpha = 0.92f),
                border = BorderStroke(1.dp, if (m.isError) cs.error.copy(alpha = 0.6f) else cs.outline.copy(alpha = 0.6f)),
                modifier = Modifier.fillMaxWidth(0.96f)
            ) {
                Column(Modifier.padding(14.dp)) {
                    if (m.isError) Text(m.text, color = cs.onErrorContainer, style = TextStyle(textDirection = TextDirection.Content))
                    else Markdown(m.text)
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (!m.isError) {
                    IconButton(onClick = onCopy, modifier = Modifier.size(36.dp)) { Icon(Icons.Filled.ContentCopy, "Copy", Modifier.size(17.dp), tint = cs.onSurfaceVariant) }
                    IconButton(onClick = onSpeak, modifier = Modifier.size(36.dp)) { Icon(Icons.AutoMirrored.Filled.VolumeUp, "Read aloud", Modifier.size(18.dp), tint = cs.onSurfaceVariant) }
                }
                if (isLast) IconButton(onClick = onRegenerate, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Filled.Refresh, if (m.isError) "Retry" else "Regenerate", Modifier.size(18.dp), tint = cs.primary)
                }
                if (m.model.isNotBlank()) Text(m.model, fontSize = 11.sp, color = cs.onSurfaceVariant, maxLines = 1, modifier = Modifier.padding(start = 4.dp))
            }
        }
    }
}

@Composable
fun LiveBubble(text: String) {
    val cs = MaterialTheme.colorScheme
    Surface(
        shape = RoundedCornerShape(20.dp, 20.dp, 20.dp, 4.dp),
        color = cs.surface.copy(alpha = 0.92f),
        border = BorderStroke(1.dp, Raza.Cyan.copy(alpha = 0.45f)),
        modifier = Modifier.fillMaxWidth(0.96f)
    ) {
        Column(Modifier.padding(14.dp)) { if (text.isEmpty()) TypingDots() else Markdown(text) }
    }
}
